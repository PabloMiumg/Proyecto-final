#include <iostream>
#include <vector>

using namespace std;

// Definici�n de la clase Plato
class Plato {
private:
    string nombre;
    float precio;

public:
    Plato(string nombre, float precio) {
        this->nombre = nombre;
        this->precio = precio;
    }

    string getNombre() {
        return nombre;
    }

    float getPrecio() {
        return precio;
    }
};

// Definici�n de la clase Pedido
class Pedido {
private:
    vector<Plato> platos;
    float total;

public:
    Pedido() {
        total = 0.0;
    }

    void agregarPlato(Plato plato) {
        platos.push_back(plato);
        total += plato.getPrecio();
    }

    void mostrarPedido() {
        cout << "Pedido:" << endl;
        for (Plato plato : platos) {
            cout << "- " << plato.getNombre() << " Q" << plato.getPrecio() << endl;
        }
        cout << "Total: Q" << total << endl;
    }
};

int main() {
    // Crear algunos platos
    Plato plato1("Pizza", 8.5);
    Plato plato2("Ensalada", 5.0);
    Plato plato3("Hamburguesa", 7.0);

    // Crear un pedido
    Pedido pedido;

    // Agregar platos al pedido
    pedido.agregarPlato(plato1);
    pedido.agregarPlato(plato2);
    pedido.agregarPlato(plato3);

    // Mostrar el pedido
    pedido.mostrarPedido();

    return 0;
}
